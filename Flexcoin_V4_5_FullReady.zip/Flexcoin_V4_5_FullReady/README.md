# Flexcoin V4.5 • Full Ready (Static Pages)

This package contains a **ready-to-upload** GitHub Pages site (no build step needed).

## How to deploy on GitHub Pages (super easy)

1. Create (or open) your repo (e.g., `soccer514514-blip/flexcoin-site`).
2. Upload the **`docs/`** folder in this zip to the root of your repo.
3. In GitHub → **Settings → Pages**:
   - **Source:** `Deploy from a branch`
   - **Branch:** `main` / **Folder:** `/docs`
4. Wait ~1 minute, then open your site.

> Your homepage is `docs/index.html` and already includes:
> - Gold theme, mobile floating **Buy FLEX (Pinksale)** button
> - Countdown (KST) to Presale start/end
> - Tokenomics donut chart image: `docs/assets/tokenomics.png`
> - Official addresses table (fetched from `/config/*.json`)
> - Allocation table from `config/allocations.json`

## Where to edit values later
- `config/presale.json` → dates, rates, button text, **PINKSALE_URL**
- `config/addresses.json` → all official wallets
- `config/tokenomics.json` → percentages for the chart labels
- `config/allocations.json` → amounts per wallet

> After you register on Pinksale, put the launchpad URL into `PINKSALE_URL` in `config/presale.json`.

## Optional
- Customize visuals in `docs/assets/style.css` and texts in `docs/index.html`.
- Add whitepaper PDFs in a `docs/whitepaper/` folder and link them from index.

Good luck! 🚀
