
async function loadConfig(){
  const res = await fetch('../config/presale.json').then(r=>r.json());
  const addr = await fetch('../config/addresses.json').then(r=>r.json());
  const tokenomics = await fetch('../config/tokenomics.json').then(r=>r.json());
  const alloc = await fetch('../config/allocations.json').then(r=>r.json());
  // Fill button
  const buy = document.querySelector('#buy');
  buy.textContent = res.BUTTON_TEXT || 'Buy FLEX (Pinksale)';
  if(res.PINKSALE_URL){ buy.href = res.PINKSALE_URL; buy.target = '_blank'; }
  // Fill addresses
  document.querySelector('#tokenAddr').textContent = addr.TOKEN_CONTRACT;
  document.querySelector('#teamAddr').textContent = addr.TEAM_LOCK_WALLET;
  document.querySelector('#presaleAddr').textContent = addr.PRESALE_WALLET;
  document.querySelector('#mktAddr').textContent = addr.MARKETING_WALLET;
  document.querySelector('#burnAddr').textContent = addr.BURN_WALLET;
  // Allocations table
  const fmt = (n)=> new Intl.NumberFormat('en-US',{maximumFractionDigits:6}).format(n);
  document.querySelector('#alloc-presale').textContent = fmt(alloc.PRESALE_WALLET_FLEX) + ' FLEX';
  document.querySelector('#alloc-team').textContent = fmt(alloc.TEAM_WALLET_FLEX) + ' FLEX';
  document.querySelector('#alloc-mkt').textContent = fmt(alloc.MARKETING_WALLET_FLEX) + ' FLEX';
  document.querySelector('#alloc-burn').textContent = fmt(alloc.BURN_WALLET_FLEX) + ' FLEX';
  document.querySelector('#alloc-lp').textContent = fmt(alloc.LP_RESERVED_FLEX) + ' FLEX';
  // Tokenomics text
  document.querySelector('#tok-lp').textContent = tokenomics.LP+'%';
  document.querySelector('#tok-pre').textContent = tokenomics.PRESALE+'%';
  document.querySelector('#tok-team').textContent = tokenomics.TEAM+'%';
  document.querySelector('#tok-mkt').textContent = tokenomics.MARKETING+'%';
  document.querySelector('#tok-burn').textContent = tokenomics.BURN+'%';
  // Countdown
  const start = new Date(res.PRESALE_START_KST);
  const end = new Date(res.PRESALE_END_KST);
  const countdownEl = document.querySelector('#countdown');
  function pad(n){return n.toString().padStart(2,'0')}
  function tick(){
    const now = new Date();
    let target = now < start ? start : end;
    let label = now < start ? 'Presale starts in' : 'Presale ends in';
    let diff = target - now;
    if(diff < 0){ countdownEl.textContent = 'Presale finished'; return; }
    const d = Math.floor(diff/86400000);
    diff -= d*86400000;
    const h = Math.floor(diff/3600000);
    diff -= h*3600000;
    const m = Math.floor(diff/60000);
    diff -= m*60000;
    const s = Math.floor(diff/1000);
    countdownEl.textContent = `${label} ${pad(d)}d:${pad(h)}h:${pad(m)}m:${pad(s)}s`;
  }
  tick(); setInterval(tick, 1000);
}
loadConfig();
