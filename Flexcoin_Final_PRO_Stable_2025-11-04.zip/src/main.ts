import './style.css';

const el = document.getElementById('app')!;

const wrap = document.createElement('div');
wrap.style.display = 'grid';
wrap.style.placeItems = 'center';
wrap.style.height = '100%';
wrap.innerHTML = `
  <div style="text-align:center">
    <h1 style="margin:0 0 6px;font-size:32px;letter-spacing:.08em;color:#ffd700">$FLEX — Flexcoin</h1>
    <p style="margin:0;color:#ddd">GitHub Pages Vite build OK</p>
  </div>
`;
el.replaceChildren(wrap);

// boot mark
const ok = document.createElement('div');
ok.className = 'ok';
ok.textContent = 'BOOT OK';
document.body.appendChild(ok);
