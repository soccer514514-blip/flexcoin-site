# Flexcoin — GitHub Pages Stable Starter

이 패키지는 GitHub Pages에서 가장 안정적으로 동작하도록 최소/필수 파일만 포함한 완성본입니다.

## 사용법
1) 저장소 루트에 그대로 업로드(덮어쓰기) → Commit
2) GitHub Actions: **Build & Deploy (Vite + Pages)** 가 성공하면 배포 완료
3) 접속 후 **Ctrl+F5** 강력 새로고침

## 스크립트
- `npm run dev` : 로컬 개발
- `npm run build:pages` : Pages용 빌드(outDir=dist, manifest 생성)

## 참고
- index.html 하단의 로더가 `/.vite/manifest.json → /manifest.json → /assets/manifest.json`
  순서로 자동 탐색합니다. 어느 위치든 200이면 앱이 실행됩니다.
