/* ---------------------------------------------------------
   On-chain Status (BSC RPC, no deps)
--------------------------------------------------------- */

const DEFAULTS = {
  chainRpc: "https://bsc-dataseed.binance.org",
  token:   "0xBa29562241F0489504C493c47aCBA16d7a98998f",
  team:    "0x8865331fD7AA6e63fC1C01882F0fE40AbC58bB30",
  marketing: "0xF3A2159474dCE4eF86F6eE56cE1b55C60E2C467e",
  user:    "0xCDcA475e1C6D89A14158fB8D05fA8275Bf5A06Ea",
  burn:    "0x388a9106d392937938721d6dd09cf1f331c2860f",
  dead:    "0x000000000000000000000000000000000000dEaD",
};

async function addRow(label: string, addr: string) {
  const tbody = document.querySelector<HTMLTableSectionElement>("#onchain tbody");
  if (!tbody) return;
  const bal = await readBalanceOf(DEFAULTS.token, addr);
  const tr = document.createElement("tr");
  tr.innerHTML = `
    <td>${label}</td>
    <td><code>${toHex32(addr)}</code></td>
    <td>${formatFlex(bal)}</td>
    <td><a class="btn btn-xs" href="https://bscscan.com/address/${addr}" target="_blank" rel="noopener">View</a></td>
  `;
  tbody.appendChild(tr);
}

async function renderOnChain() {
  await addRow("Team / Lock",        DEFAULTS.team);
  await addRow("Marketing / Airdrop",DEFAULTS.marketing);
  await addRow("Your wallet",        DEFAULTS.user);
  await addRow("Dead (Burn)",        DEFAULTS.burn);
  await addRow("Zero (0x…dEaD)",     DEFAULTS.dead);

  const totalEl = document.querySelector<HTMLElement>("#totalSupply");
  if (totalEl) {
    const ts = await readTotalSupply(DEFAULTS.token);
    totalEl.textContent = String(ts);
  }
}

renderOnChain().catch(console.warn);
