# Flexcoin Mainnet — Final Build Patch (2025‑11‑08)

This patch updates your existing repo to the latest finalized wiring:
- Adds **burn/dead** rows to On‑chain table (no deps, BSC RPC)
- Keeps all addresses in one place and updates **public/config/** JSON
- Unifies CSS link to `/style.css`
- Verifies hero & NFT preview asset paths
- One‑click PowerShell script: `apply_flexcoin_final_patch.ps1`

## What this patch contains
- `PATCH/main.ts.snippet.ts` — drop‑in section for `/src/main.ts` (between the on‑chain markers)
- `public/config/addresses.json` — canonical address set (BSC mainnet)
- `public/config/presale.json` — presale KST schedule
- `apply_flexcoin_final_patch.ps1` — one‑click patcher (run from repo root)
- `VERIFY.md` — quick checklist

## Quick use (Windows PowerShell, from your repo root)
1. Unzip anywhere.
2. Right‑click **PowerShell** → **Run as Administrator**.
3. `cd` into your repo (e.g. `cd $env:USERPROFILE\Desktop\flexcoin-site`).
4. Run:
   ```powershell
   powershell -ExecutionPolicy Bypass -File "<PATH-TO-UNZIPPED>/apply_flexcoin_final_patch.ps1"
   ```
5. Wait for the GitHub Actions green check ✓ then hard refresh your site (Ctrl+F5).

---

Patch created at: 2025-11-08T00:58:09.260912Z
