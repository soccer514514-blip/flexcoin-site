# apply_flexcoin_final_patch.ps1
param(
  [string]$RepoPath = (Get-Location).Path,
  [string]$PatchRoot = (Split-Path -Parent $MyInvocation.MyCommand.Path)
)

Write-Host "`n== Flexcoin Final Patch ==" -ForegroundColor Cyan
Write-Host "Repo: $RepoPath"
Write-Host "Patch: $PatchRoot`n"

$ErrorActionPreference = "Stop"

# Ensure config dir
$newCfg = Join-Path $RepoPath "public\config"
if (!(Test-Path $newCfg)) { New-Item -ItemType Directory -Path $newCfg | Out-Null }

# Copy JSONs
Copy-Item (Join-Path $PatchRoot "public\config\addresses.json") $newCfg -Force
Copy-Item (Join-Path $PatchRoot "public\config\presale.json") $newCfg -Force

# Normalize index.html -> link to /style.css and hero path
$idx = Join-Path $RepoPath "index.html"
if (Test-Path $idx) {
  $h = Get-Content $idx -Raw -Encoding UTF8
  $h = $h -replace 'href="/src/style\.css"', 'href="/style.css"'
  $h = $h -replace 'href="/styles\.css"', 'href="/style.css"'
  $h = $h -replace 'src="/public/hero/([1-7])\.jpg"', 'src="/hero/$1.jpg"'
  Set-Content $idx $h -Encoding UTF8
  Write-Host "index.html normalized."
}

# Inject on-chain snippet in src/main.ts by replacing the block between markers or falling back to regex
$mt = Join-Path $RepoPath "src\main.ts"
if (Test-Path $mt) {
  $code = Get-Content $mt -Raw -Encoding UTF8
  $snippet = Get-Content (Join-Path $PatchRoot "PATCH\main.ts.snippet.ts") -Raw -Encoding UTF8

  $pattern = '(?s)/\* *[-]{5,}\s*On-chain Status.*?[-]{5,}\s*\*/.*?renderOnChain\(\)\.catch\(console\.warn\);'
  if ($code -match $pattern) {
    $code = [regex]::Replace($code, $pattern, $snippet)
  } else {
    $code = $code + "`r`n`r`n" + $snippet
  }

  Set-Content $mt $code -Encoding UTF8
  Write-Host "main.ts patched."
}

# Git commit (optional)
Set-Location $RepoPath
if (-not (git config user.email)) {
  git config user.name "Flex Bot"
  git config user.email "flexcoin-bot@example.local"
}
git add -A
git commit -m "Final patch: burn/dead rows, config JSON, CSS & hero path normalize" | Out-Null
git pull --rebase origin main
git push origin main

Write-Host "`nDone. Visit: https://flexcoin.io.kr/?v=$(Get-Date -Format yyyyMMddHHmmss)" -ForegroundColor Green
