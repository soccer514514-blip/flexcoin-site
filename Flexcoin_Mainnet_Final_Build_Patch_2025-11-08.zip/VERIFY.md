# Verify after deploy

- [ ] On-chain table shows 5 rows: Team/Lock, Marketing/Airdrop, Your wallet, Dead (Burn), Zero (0x…dEaD)
- [ ] Each row has working **View** → BscScan
- [ ] **Total Supply** renders
- [ ] Top hero image renders (no 'public/' prefix): `/hero/1.jpg`
- [ ] NFT previews 1..6 render from `/nft-preview/publicnft-previewX.jpg`
- [ ] Buttons work: PancakeSwap / Telegram / X / BscScan
- [ ] No 404s for `/config/presale.json` and `/config/addresses.json`
- [ ] Console has no red errors
