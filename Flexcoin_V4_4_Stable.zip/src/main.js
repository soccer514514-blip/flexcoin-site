// Load config
async function loadConfig(){
  const res = await fetch('/config/addresses.json');
  return res.json();
}

function fmt(n){return n.toString().padStart(2,'0');}

function startCountdown(targetKST, el){
  // targetKST: "2025-12-01T21:00:00+09:00"
  const target = new Date(targetKST).getTime();
  function tick(){
    const now = Date.now();
    let diff = Math.max(0, target - now);
    const d = Math.floor(diff/86400000); diff%=86400000;
    const h = Math.floor(diff/3600000); diff%=3600000;
    const m = Math.floor(diff/60000); diff%=60000;
    const s = Math.floor(diff/1000);
    el.innerHTML = ['days','hrs','min','sec'].map((k,i)=>{
      const v = [d,h,m,s][i];
      return `<div class="cell"><div style="font-size:22px">${fmt(v)}</div><div style="opacity:.8">${k}</div></div>`;
    }).join('');
    requestAnimationFrame(()=>setTimeout(tick,500));
  }
  tick();
}

// Preload images
function preload(urls){ urls.forEach(u=>{ const i=new Image(); i.src=u;}); }

// Donut chart
function drawDonut(canvas, items){
  if(!canvas) return;
  const DPR = window.devicePixelRatio||1;
  const ctx = canvas.getContext('2d');
  const W = canvas.clientWidth*DPR, H = canvas.clientHeight*DPR;
  canvas.width=W; canvas.height=H;
  const cx=W/2, cy=H/2, R=Math.min(W,H)/2-8*DPR, r=R*0.62;
  const total = items.reduce((a,b)=>a+b.value,0)||1;
  let a0 = -Math.PI/2;
  const base=[50,120,190,260,320];
  items.forEach((it,idx)=>{
    const a1 = a0 + 2*Math.PI*(it.value/total);
    ctx.beginPath(); ctx.arc(cx,cy,R,a0,a1); ctx.arc(cx,cy,r,a1,a0,true); ctx.closePath();
    ctx.fillStyle = `hsl(${base[idx%base.length]} 80% 58%)`; ctx.fill();
    a0=a1;
  });
  ctx.fillStyle='#f5e6b3'; ctx.font=`${16*DPR}px system-ui`; ctx.textAlign='center';
  ctx.fillText('Tokenomics', cx, cy+6*DPR);
}

function makeCard(src, title){
  return `<div class="card"><img src="${src}" alt="${title}"><div class="title">${title}</div></div>`;
}

(async function(){
  const cfg = await loadConfig();

  // Wire buttons
  document.getElementById('btnBuy').href = cfg.links.pancake;
  document.getElementById('btnScan').href = cfg.links.bscscan;
  document.getElementById('btnTG').href = cfg.links.telegram;
  document.getElementById('btnX').href = cfg.links.twitter;

  // Countdown
  startCountdown(cfg.presale_kst, document.getElementById('timer'));

  // Hero rotator
  const heroImgs = Array.from({length:8}, (_,i)=>`/public/hero/${i+1}.jpg`);
  preload(heroImgs);
  let cur=0; const hero=document.getElementById('heroImg');
  setInterval(()=>{ cur=(cur+1)%heroImgs.length; hero.style.opacity=0; setTimeout(()=>{ hero.src=heroImgs[cur]; hero.style.opacity=1;},300); }, 5000);

  // Action & NFT grids
  const action = document.getElementById('actionGrid');
  const nft = document.getElementById('nftGrid');
  action.innerHTML = Array.from({length:8},(_,i)=>makeCard(`/public/action/${i+1}.jpg`, `Action ${i+1}`)).join('');
  nft.innerHTML = Array.from({length:8},(_,i)=>makeCard(`/public/nft-preview/${i+1}.jpg`, `NFT ${i+1}`)).join('');

  // Tokenomics
  drawDonut(document.getElementById('donut'), cfg.tokenomics||[]);
  const legend = document.getElementById('legend');
  const hues=[50,120,190,260,320];
  legend.innerHTML = (cfg.tokenomics||[]).map((t,i)=>`
    <div style="display:flex;align-items:center;gap:8px">
      <span style="width:12px;height:12px;border-radius:50%;background:hsl(${hues[i%5]} 80% 58%)"></span>
      <span>${t.label}: <b>${t.value}%</b></span>
    </div>`).join('');

  // Whitepaper tiles
  const langs = ['en','ko','ja','zh','es','de','pt','it'];
  const wp = document.getElementById('wpGrid');
  wp.innerHTML = langs.map(code=>`
    <a class="card" href="/public/whitepaper/whitepaper_${code}.pdf" target="_blank" rel="noopener">
      <span style="font-size:20px">${code.toUpperCase()} PDF</span>
    </a>`).join('');
})();