# === Flexcoin ZIP Packager for Windows PowerShell ===
Write-Host "🎯 Flexcoin packager started..." -ForegroundColor Yellow

$base = "$PSScriptRoot"
$src  = $base
$dst  = Join-Path $base "flexcoin_zips_out"
New-Item -ItemType Directory -Force -Path $dst | Out-Null

$targets = @(
  "public/hero",
  "public/action",
  "public/nft-preview",
  "public/whitepaper",
  "src",
  "config",
  "index.html",
  "favicon.ico"
)

foreach ($t in $targets) {
  $path = Join-Path $src $t
  if (Test-Path $path) {
    $zipName = ($t -replace "[\\/]", "_") + ".zip"
    $zipPath = Join-Path $dst $zipName
    Write-Host "📦 Packaging $t -> $zipName"
    Compress-Archive -Path $path -DestinationPath $zipPath -Force
  } else {
    Write-Host "⚠️  Missing: $t" -ForegroundColor Red
  }
}

Write-Host "✅ All done! Check the folder:" -ForegroundColor Green
Write-Host "  " $dst
