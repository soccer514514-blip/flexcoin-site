Flexcoin – Full Upgrade Patch (b)
Date: 2025-11-07T10:10:20.077931Z

What changed
- NFT preview loader now supports both naming styles:
  /public/nft-preview/1.jpg … 6.jpg  (recommended)
  /public/nft-preview/publicnft-preview1.jpg … 6.jpg  (your files)
- Keeps hero 404 fix, BSC mainnet wiring, presale timer (KST 21:00),
  PancakeSwap link, donut chart, wallet/explorer links.

How to use
1) Upload/drag the whole zip contents to your repo root (overwrite).
2) Put your 6 preview images into public/nft-preview/ using your current names.
   (You can also rename them to 1.jpg … 6.jpg if you prefer.)
3) Commit & push → GitHub Pages deploys automatically.
