// ===== FLEX ⸺ Main Script (2025‑11‑07b) =====

// ---- Constants (BSC Mainnet)
const CHAIN_ID_HEX = '0x38'; // 56
const TOKEN = '0xBa29562241F0489504C493c47aCBA16d7a98998f';
const W_TEAM = '0x8865331fD7AA6e63fC1C01882F0fE40AbC58bB30';
const W_MKT  = '0xF3A2159474dCE4eF86F6eE56cE1b55C60E2C467e';
const W_USER = '0xCDcA475e1C6D89A14158fB8d05fA8275Bf5A06Ea';

// ---- Presale (KST 21:00)
const PRESALE_START = Date.UTC(2025,11-1,1,12); // 21:00 KST = 12:00 UTC
const PRESALE_END   = Date.UTC(2026, 1-1,1,12);

// ---- Hero 404 fix
const HERO_VER = new URLSearchParams(location.search).get('v') || String(Date.now());
const HERO_BASE = '/public/hero/';
function fixHero(){
  const img = document.getElementById('hero-img') as HTMLImageElement | null;
  if(!img) return;
  const try1 = `${HERO_BASE}1.jpg?v=${HERO_VER}`;
  const try2 = `${HERO_BASE}2.jpg?v=${HERO_VER}`;
  img.src = try1;
  img.onerror = ()=>{ img.onerror=null; img.src = try2; };
}

// ---- MetaMask connect
async function connect(){
  const ethereum = (window as any).ethereum;
  if(!ethereum){ alert('MetaMask가 필요합니다.'); return; }
  const cid = await ethereum.request({ method:'eth_chainId' });
  if(cid !== CHAIN_ID_HEX){
    await ethereum.request({ method:'wallet_switchEthereumChain', params:[{ chainId: CHAIN_ID_HEX }] }).catch(async (e:any)=>{
      if(e.code === 4902){
        await ethereum.request({ method:'wallet_addEthereumChain', params:[{ chainId: CHAIN_ID_HEX, chainName:'BNB Smart Chain', nativeCurrency:{name:'BNB',symbol:'BNB',decimals:18}, rpcUrls:['https://bsc-dataseed.binance.org/'], blockExplorerUrls:['https://bscscan.com/'] }] });
      } else { throw e; }
    });
  }
  await ethereum.request({ method:'eth_requestAccounts' });
  (document.getElementById('connect') as HTMLButtonElement).textContent = '지갑 연결됨';
}

// ---- Presale countdown
function tickCountdown(){
  const el = document.getElementById('countdown'); if(!el) return;
  const now = Date.now();
  let label = '';
  let target = PRESALE_START;
  if(now >= PRESALE_END){ label='Ended'; target=now; }
  else if(now >= PRESALE_START){ label='LIVE · ends in'; target=PRESALE_END; }
  else { label='Starts in'; target=PRESALE_START; }
  const ms = Math.max(0, target - now);
  const s = Math.floor(ms/1000)%60;
  const m = Math.floor(ms/1000/60)%60;
  const h = Math.floor(ms/1000/60/60)%24;
  const d = Math.floor(ms/1000/60/60/24);
  el.textContent = `${label} ${d}d ${h}h ${m}m ${s}s`;
}
setInterval(tickCountdown, 1000);

// ---- Donut chart
function donut(){
  const cv = document.getElementById('donut') as HTMLCanvasElement | null; if(!cv) return;
  const ctx = cv.getContext('2d')!;
  const data = [
    { v:69, c:getComputedStyle(document.documentElement).getPropertyValue('--gold') || '#d7b76d' },
    { v:10, c:'#f5c542' },
    { v:10, c:'#f59f42' },
    { v:10, c:'#f57f42' },
    { v:1,  c:'#999' },
  ];
  const sum = data.reduce((a,b)=>a+b.v,0);
  let a0 = -Math.PI/2;
  data.forEach(d=>{
    const ang = (d.v/sum)*Math.PI*2;
    ctx.beginPath(); ctx.moveTo(160,160);
    ctx.arc(160,160,150,a0,a0+ang); ctx.closePath();
    ctx.fillStyle = d.c.trim(); ctx.fill();
    a0+=ang;
  });
  // hole
  ctx.globalCompositeOperation = 'destination-out';
  ctx.beginPath(); ctx.arc(160,160,96,0,Math.PI*2); ctx.fill();
  ctx.globalCompositeOperation = 'source-over';
}

// ---- Links
function bindLinks(){
  const buy = document.getElementById('buy') as HTMLAnchorElement;
  const ex  = document.getElementById('explorer') as HTMLAnchorElement;
  buy.href = `https://pancakeswap.finance/swap?outputCurrency=${TOKEN}`;
  ex.href  = `https://bscscan.com/token/${TOKEN}`;
  (document.getElementById('x') as HTMLAnchorElement).href = 'https://x.com/Flexcoinmeme';
  (document.getElementById('tg') as HTMLAnchorElement).href = 'https://t.me/+p1BMrdypmDFmNTA1';

  const w = (id:string, addr:string)=>{
    const a = document.getElementById(id) as HTMLAnchorElement;
    a.href = `https://bscscan.com/address/${addr}`;
    a.textContent = addr;
  };
  w('w-team', W_TEAM); w('w-mkt', W_MKT); w('w-user', W_USER);
}

// ---- NFT preview grid with dual-name fallback
function renderNFTPreview(){
  const root = document.getElementById('nft-grid'); if(!root) return;
  const primary = [1,2,3,4,5,6].map(n=>`/public/nft-preview/${n}.jpg`);
  const alt     = [1,2,3,4,5,6].map(n=>`/public/nft-preview/publicnft-preview${n}.jpg`);
  const all = primary.map((p,i)=>[p, alt[i]]);
  all.forEach(pair=>{
    const img = new Image(); img.loading='lazy'; img.decoding='async';
    img.src = pair[0];
    img.onerror = ()=>{ img.onerror=null; img.src = pair[1]; };
    img.alt = 'Flex your NFT — preview';
    img.style.width='100%'; img.style.borderRadius='12px'; img.style.background='#0b0b0b';
    root.appendChild(img);
  });
}

// ---- Boot
window.addEventListener('DOMContentLoaded', ()=>{
  fixHero(); donut(); bindLinks(); renderNFTPreview(); tickCountdown();
  document.getElementById('connect')?.addEventListener('click', connect);
});
